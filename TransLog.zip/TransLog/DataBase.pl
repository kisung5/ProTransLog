%%%%%%%%%%%Sustantivos (Nouns)%%%%%%%%%%%%%%%%%%%

sust(masculino, singular,"hombre", "man").
sust(masculino, plural,  "hombres", "men").
sust(femenino, singular, "manzana", "apple").
sust(femenino, plural, "manzanas", "apples").
sust(femenino, singular, "costa rica", "costa rica").
sust(femenino, singular, "alemania", "germany").
sust(femenino, singular, "carne", "meat").
sust(femenino, plural, "carnes", "meats").
sust(masculino, plural, "seres vivos", "living beings").
sust(masculino, singular, "correr", "turron").
sust(femenino,singular,"a","to").
sust(femenino,singular,"una","a").
sust(femenino,singular,"o","or").
sust(singular,singular,"esta","this").
sust(masculino,singular,"ser","be").
sust(masculino,singular,"son","They are").
sust(singular,singular,"fue","It was").
sust(femenino,singular,"era","was").
sust(masculino,plural,"anos","years").
sust(femenino,singular,"vez","time").
sust(masculino,singular,"puede","can").
sust(femenino,singular,"parte","part").
sust(masculino,singular,"tiene","has").
sust(masculino,singular,"tiempo","weather").
sust(femenino,singular,"vida","lifetime").
sust(femenino,singular,"te","tea").
sust(masculino,singular,"gobierno","government").
sust(masculino,singular,"dia","day").
sust(masculino,singular,"tanto","so much").
sust(masculino,singular,"sido","been").
sust(masculino,plural,"pais","country").
sust(masculino,singular,"mundo","world").
sust(masculino,singular,"ano","year").
sust(masculino,singular,"estado","state").
sust(femenino,singular,"forma","shape").
sust(masculino,singular,"caso","case").
sust(femenino,singular,"nada","nothing").
sust(masculino,singular,"general","general").
sust(femenino,singular,"casa","home").
sust(masculino,singular,"hecho","fact").
sust(masculino,singular,"momento","moment").
sust(masculino,plural,"millones","millions").
sust(masculino,singular,"hombre","man").
sust(masculino,singular,"lugar","place").
sust(masculino,singular,"trabajo","job").
sust(masculino,singular,"decir","to say").
sust(masculino,singular,"debe","should").
sust(femenino,singular,"politica","politics").
sust(masculino,singular,"pasado","past").
sust(singular,singular,"estas","these").
sust(masculino,singular,"poder","to be able to").
sust(masculino,singular,"poder","power").
sust(masculino,singular,"ver","to see").
sust(femenino,plural,"veces","times").
sust(masculino,singular,"embargo","embargo").
sust(masculino,singular,"partido","match").
sust(femenino,plural,"personas","people").
sust(masculino,singular,"grupo","group").
sust(femenino,singular,"cuenta","account").
sust(masculino,singular,"pueden","may").
sust(masculino,singular,"tienen","they have").
sust(femenino,singular,"nueva","new").
sust(singular,singular,"fueron","were").
sust(femenino,singular,"mujer","woman").
sust(femenino,singular,"frente","front").
sust(femenino,plural,"cosas","things").
sust(masculino,singular,"fin","end").
sust(femenino,singular,"ciudad","city").
sust(femenino,singular,"manera","way").
sust(masculino,singular,"tener","to have").
sust(masculino,singular,"sistema","system").
sust(femenino,singular,"historia","history").
sust(masculino,singular,"tipo","kind").
sust(masculino,singular,"punto","point").
sust(masculino,singular,"dice","says").
sust(femenino,singular,"noche","night").
sust(femenino,singular,"agua","Water").
sust(singular,singular,"parece","It seems").
sust(femenino,singular,"situacion","situation").
sust(masculino,singular,"ejemplo","example").
sust(masculino,singular,"acuerdo","agreement").
sust(masculino,plural,"estados","state").
sust(masculino,singular,"hizo","did").
sust(masculino,plural,"paises","countries").
sust(femenino,plural,"horas","hours").
sust(femenino,singular,"ley","law").
sust(femenino,singular,"guerra","war").
sust(masculino,singular,"desarrollo","development").
sust(masculino,singular,"proceso","process").
sust(femenino,singular,"realidad","reality").
sust(masculino,singular,"sentido","sense").
sust(masculino,singular,"lado","side").
sust(masculino,singular,"cambio","change").
sust(femenino,singular,"mano","hand").
sust(masculino,singular,"eran","they were").
sust(singular,singular,"estar","to be").
sust(masculino,singular,"numero","number").
sust(femenino,singular,"sociedad","society").
sust(masculino,singular,"unas","nail").
sust(masculino,singular,"centro","center").
sust(masculino,singular,"padre","father").
sust(femenino,singular,"gente","people").
sust(masculino,singular,"final","final").
sust(femenino,singular,"relacion","relationship").
sust(masculino,singular,"cuerpo","body").
sust(femenino,singular,"obra","work").
sust(femenino,singular,"madre","mother").
sust(masculino,singular,"modo","mode").
sust(masculino,plural,"problemas","problems").
sust(masculino,plural,"hombres","men").
sust(femenino,singular,"informacion","information").
sust(masculino,plural,"ojos","eyes").
sust(femenino,singular,"muerte","death").
sust(masculino,singular,"sust","first name").
sust(femenino,plural,"mujeres","women").
sust(masculino,singular,"siglo","century").
sust(masculino,plural,"meses","months").
sust(femenino,singular,"manana","morning").
sust(femenino,singular,"hora","hour").
sust(masculino,singular,"pueblo","town").
sust(masculino,singular,"dar","give").
sust(masculino,singular,"problema","problem").
sust(masculino,singular,"don","Don").
sust(femenino,singular,"da","gives").
sust(femenino,singular,"verdad","true").
sust(femenino,singular,"maria","Maria").
sust(masculino,singular,"podria","could").
sust(masculino,singular,"seria","would").
sust(femenino,singular,"cabeza","head").
sust(femenino,singular,"tierra","Earth").
sust(masculino,singular,"equipo","equipment").
sust(masculino,plural,"casos","cases").
sust(masculino,singular,"nivel","level").
sust(femenino,singular,"familia","family").
sust(singular,singular,"partir","to split").
sust(femenino,singular,"falta","lack").
sust(singular,singular,"llegar","arrive").
sust(femenino,singular,"cosa","thing").
sust(femenino,singular,"seguridad","security").
sust(femenino,singular,"trata","about").
sust(masculino,singular,"tuvo","had").
sust(masculino,singular,"respecto","respect").
sust(femenino,singular,"semana","week").
sust(femenino,singular,"voz","voice").
sust(masculino,singular,"paso","passed").
sust(masculino,singular,"proyecto","draft").
sust(masculino,singular,"mercado","market").
sust(femenino,singular,"mayoria","most").
sust(femenino,singular,"luz","light").
sust(masculino,singular,"este","East").
sust(femenino,plural,"pesetas","pesetas").
sust(masculino,singular,"orden","order").
sust(masculino,singular,"programa","Program").
sust(femenino,plural,"palabras","words").
sust(femenino,singular,"empresa","company").
sust(masculino,singular,"puesto","Market Stall").
sust(femenino,singular,"m","m").
sust(masculino,singular,"libro","book").
sust(femenino,singular,"persona","person").
sust(masculino,singular,"total","total").
sust(femenino,singular,"c","c").
sust(femenino,plural,"condiciones","terms").
sust(masculino,singular,"mexico","Mexico").
sust(femenino,singular,"fuerza","force").
sust(femenino,singular,"accion","action").
sust(masculino,singular,"amor","love").
sust(femenino,singular,"puerta","door").
sust(masculino,singular,"pesar","to weigh").
sust(femenino,singular,"zona","zone").
sust(masculino,singular,"sabe","knows").
sust(femenino,singular,"calle","Street").
sust(femenino,singular,"musica","music").
sust(femenino,singular,"vista","view").
sust(masculino,singular,"campo","countryside").
sust(masculino,singular,"saber","to know").
sust(femenino,plural,"obras","works").
sust(femenino,singular,"razon","reason").
sust(femenino,singular,"presencia","presence").
sust(masculino,singular,"tema","theme").
sust(masculino,singular,"dinero","money").
sust(femenino,singular,"comision","commission").
sust(masculino,singular,"servicio","service").
sust(masculino,singular,"ultima","last").
sust(masculino,singular,"ciento","hundred").
sust(singular,singular,"hablar","to talk").
sust(masculino,plural,"minutos","minutes").
sust(femenino,singular,"produccion","production").
sust(masculino,singular,"camino","path").
sust(masculino,singular,"fondo","background").
sust(femenino,singular,"direccion","address").
sust(masculino,singular,"papel","paper").
sust(femenino,singular,"idea","idea").
sust(masculino,singular,"dado","dice").
sust(femenino,singular,"base","base").
sust(femenino,singular,"capital","capital").
sust(femenino,singular,"europa","Europe").
sust(femenino,singular,"libertad","freedom").
sust(masculino,singular,"espacio","space").
sust(singular,singular,"ir","to go").
sust(femenino,singular,"poblacion","population").
sust(femenino,plural,"empresas","Business").
sust(masculino,singular,"estudio","study").
sust(femenino,singular,"salud","Health").
sust(masculino,plural,"servicios","services").
sust(femenino,singular,"haya","beech").
sust(masculino,singular,"principio","beginning").
sust(masculino,singular,"siendo","being").
sust(femenino,singular,"cultura","culture").
sust(femenino,singular,"media","half").
sust(masculino,singular,"arte","art").
sust(femenino,singular,"paz","peace").
sust(masculino,singular,"sector","sector").
sust(femenino,singular,"imagen","image").
sust(femenino,singular,"medida","measure").
sust(masculino,singular,"deben","must").
sust(masculino,plural,"datos","data").
sust(masculino,singular,"consejo","advice").
sust(masculino,plural,"interes","interest").
sust(masculino,singular,"julio","July").
sust(masculino,plural,"grupos","groups").
sust(masculino,plural,"miembros","members").
sust(singular,singular,"existit","to exist").
sust(femenino,singular,"cara","expensive").
sust(femenino,singular,"edad","age").
sust(masculino,singular,"movimiento","movement").
sust(masculino,plural,"puntos","points").
sust(femenino,singular,"actividad","activity").
sust(masculino,singular,"uso","use").
sust(masculino,singular,"futuro","future").
sust(masculino,plural,"mes","month").
sust(femenino,singular,"posibilidad","possibility").
sust(masculino,singular,"seguir","to follow").
sust(masculino,plural,"resultados","results").
sust(femenino,singular,"educacion","education").
sust(femenino,singular,"atencion","Attention").
sust(femenino,singular,"capacidad","capacity").
sust(masculino,singular,"efecto","effect").
sust(masculino,singular,"valor","value").
sust(masculino,singular,"aire","air").
sust(femenino,singular,"investigacion","investigation").
sust(femenino,singular,"figura","figure").
sust(femenino,singular,"comunidad","community").
sust(femenino,singular,"necesidad","need").
sust(femenino,singular,"serie","series").
sust(femenino,singular,"organizacion","organization").
sust(femenino,plural,"nuevas","new").
sust(masculino,singular,"comer","to eat").
sust(masculino,singular,"cocinar","to cook").

sust(masculino,singular, "perro", "dog").
sust(masculino,plural, "perros", "dogs").
sust(masculino,singular, "gato", "cat").
sust(masculino, plural, "gatos", "cats").
sust(masculino, singular, "caballo", "horse").
sust(masculino, plural, "caballos", "horses").
sust(masculino, singular, "pajaro", "bird").
sust(masculino, plural, "pajaros", "birds").
sust(masculino, singular, "oso", "bear").
sust(masculino, plural, "osos", "bears").
sust(masculino, singular, "conejo", "rabbit").
sust(masculino, plural, "conejos", "rabbits").
sust(masculino, singular, "zorro", "fox").
sust(masculino, plural, "zorros", "foxes").
sust(masculino, singular, "lobo", "wolf").
sust(masculino, plural, "lobos", "wolves").
sust(masculino, singular, "pez", "fish").
sust(masculino, plural, "peces", "fish").
sust(femenino, singular, "vaca", "cow").
sust(femenino, plural, "vacas", "cows").
sust(femenino, singular, "abeja", "bee").
sust(femenino, plural, "abejas", "bees").
sust(femenino, singular, "ballena", "whale").
sust(femenino, plural, "ballenas", "whales").
sust(femenino, singular, "rata", "rat").
sust(femenino, plural, "ratas", "rats").
sust(masculino, singular, "arbol", "tree").
sust(masculino, plural, "arboles", "trees").
sust(masculino, singular, "avion", "airplane").
sust(masculino, singular, "barco", "ship").
sust(fememnino, singular, "montana", "mountain").
sust(masculino, singular, "rio", "river").
sust(masculino, singular, "instituto", "institute").
sust(femenino, singular, "calle", "street").
sust(femenino, singular, "camara", "camera").
sust(masculino, singular, "plastico", "plastic").
sust(masculino, singular, "cuchillo", "knife").
sust(masculino, plural, "cuchillos", "knives").


sust(masculino, singular, "abogado", "lawyer").
sust(masculino, plural, "abogados", "lawyers").
sust(masculino, singular, "chef", "chef").
sust(masculino, singular, "actor", "actor").
sust(femenino, singular, "actriz", "actress").
sust(masculino, plural, "actores", "actors").
sust(masculino, singular, "esposo", "husband").
sust(femenino, singular, "esposa", "wife").
sust(masculino, singular, "hijo", "son").
sust(femenino, singular, "hija", "daughter").
sust(masculino, plural, "hijos", "children").
sust(femenino, plural, "hijas", "children").
sust(masculino, singular, "tio", "uncle").
sust(femenino, singular, "tia", "aunt").
sust(masculino, singular, "abuelo", "grandfather").
sust(femenino, singular, "abuela", "grandmother").
sust(masculino, plural, "abuelos", "grandparents").
sust(masculino, singular, "hermano", "brother").
sust(femenino, singular, "hermana", "sister").
sust(masculino, singular, "doctor", "doctor").
sust(masculino, singular, "bebe", "baby").
sust(masculino, plural, "doctors", "doctors").
sust(femenino, singular, "enfermera", "nurse").
sust(femenino, plural, "enfermeras", "nurses").
sust(masculino, singular, "ingeniero", "engineer").
sust(femenino, singular, "ingeniera", "engineer").
sust(masculino, singular, "jefe", "boss").
sust(masculino, singular, "presidente", "president").
sust(masculino, singular, "artista", "artist").
sust(femenino, singular, "artista", "artist").
sust(masculino, singular, "amigo", "friend").
sust(femenino, singular, "amiga", "friend").
sust(masculino, plural, "amigos", "friends").
sust(masculino, singular, "panadero", "baker").
sust(masculino, singular, "musico", "musician").
sust(masculino, plural, "musicos", "musician").
sust(masculino, singular, "cantante", "singer").
sust(masculino, singular, "soldado", "soldier").
sust(masculino, singular, "chofer", "driver").
sust(masculino, singular, "juez", "jugde").
sust(masculino, singular, "nino", "boy").
sust(femenino, singular, "nina", "girl").
sust(masculino, singular, "lector", "reader").
sust(masculino, singular, "lider", "leader").
sust(masculino, singular, "maestro", "teacher").
sust(masculino, singular, "profesor", "professor").
sust(masculino, singular, "policia", "police").

sust(masculino, singular, "hospital", "hospital").
sust(masculino, singular, "hotel", "hotel").
sust(femenino, singular, "casa", "house").
sust(masculino, singular, "aula", "classroom").
sust(masculino, singular, "bano", "bathroom").
sust(masculino, singular, "cuarto", "room").
sust(femenino, singular, "cocina", "kitchen").

sust(femenino, singular, "manzana", "apple").
sust(femenino, singular, "sandia", "watermelon").
sust(masculino, singular, "pan", "bread").
sust(femenimo, singular, "comida", "food").
sust(masculino, singular, "pescado", "fish").
sust(femenino, singular, "naranja", "orange").
sust(femenino, singular, "ensalada", "salad").


sust(neutro, singular, "yo", "i").
sust(neutro, singular, "yo", "me").
sust(neutro, singular, "me", "i").
sust(neutro, plural, "nosotros", "we").
sust(neutro, plural, "nos", "we").
sust(neutro, plural, "nosotras", "we").
sust(neutro, singular, "vos", "you").
sust(neutro, singular, "tu", "you").
sust(neutro, singular, "ti", "you").
sust(neutro, singular, "te", "you").
sust(neutro, plural, "vosotros", "you").
sust(neutro, plural, "vosotras", "you").
sust(neutro, plural, "vos", "you").
sust(neutro, plural, "os", "you").
sust(neutro, singular, "ella", "she").
sust(neutro, singular, "el", "he").
sust(neutro, plural, "ellos", "they").
sust(neutro, plural, "ellas", "they").
sust(neutro, plural, "les", "they").

sust(_, _, [], []).

%%%%%%%%%%%%%Articulos(Article)%%%%%%%%%%%%%%%%%%%%%

determinante(femenino, plural, "las", "the").
determinante(femenino, singular, "la", "the").
determinante(masculino, singular, "el", "the").
determinante(masculino, plural, "los", "the").
determinante(masculino, singular, "esa", "that").
determinante(masculino, singular, "esta", "this").
determinante(femenino, singular, "una", "a").
determinante(femenino, plural, "unas", "some").
determinante(masculino, singular, "un", "a").
determinante(masculino, plural, "unos", "some").
determinante(femenino,singular,"la","the").
determinante(masculino,singular,"el","the").
determinante(masculino,plural,"los","the").
determinante(femenino,plural,"las","the").

determinante(_, _, [], []).

%%%%%%%%%%%%%%%Verbos(Verbs)%%%%%%%%%%%%%%%%%

verbo(plural, primera, "comemos", "eat").
verbo(plural, primera, "comimos", "ate").
verbo(plural, primera, "comeremos", "will eat").
verbo(plural, segunda, "comen", "eat").
verbo(plural, segunda, "comieron", "eat").
verbo(plural, segunda, "comeran", "will eat").
verbo(plural, tercera, "comen", "eat").
verbo(plural, tercera, "comieron", "ate").
verbo(plural, tercera, "comeran", "will eat").
verbo(singular, primera, "como", "eat").
verbo(singular, primera, "comi", "ate").
verbo(singular, primera, "comere", "will eat").
verbo(singular, segunda, "comes", "eat").
verbo(singular, segunda, "comiste", "ate").
verbo(singular, segunda, "comeras", "will eat").
verbo(singular, tercera, "come", "eats").
verbo(singular, tercera, "comio", "ate").
verbo(singular, tercera, "comera", "will eat").
verbo(singular, segunda, "quieres","want").
%ser
verbo(plural, primera, "somos", "are").
verbo(plural, primera, "fuimos", "were").
verbo(plural, primera, "seremos", "will be").
verbo(plural, segunda, "son", "are").
verbo(plural, segunda, "eran", "were").
verbo(plural, segunda, "seran", "will be").
verbo(plural, tercera, "son", "are").
verbo(plural, tercera, "eran", "were").
verbo(plural, tercera, "seran", "will be").
verbo(singular, primera, "soy", "am").
verbo(singular, primera, "fui", "was").
verbo(singular, primera, "sere", "will be").
verbo(singular, segunda, "eres", "are").
verbo(singular, segunda, "fuiste", "were").
verbo(singular, segunda, "seras", "will be").
verbo(singular, tercera, "es", "is").
verbo(singular, tercera, "fue", "was").
verbo(singular, tercera, "sera", "will be").
%poder
verbo(singular,primera,"puedo","may").
verbo(singular,segunda,"puedes","can").
verbo(singular,tercera,"puede","can").
verbo(plural,primera,"podemos","can").
verbo(plural,tercera,"pueden","may").
verbo(singular,primera,"pude","could").
verbo(singular,segunda,"pudiste","could").
verbo(singular,tercera,"pudo","could").
verbo(plural,primera,"pudimos","could").
verbo(plural,tercera,"pudieron","could").
verbo(singular,primera,"podria","will be able").
verbo(singular,segunda,"podria","can").
verbo(singular,tercera,"podria","may").
verbo(plural,primera,"podremos","can").
verbo(plural,tercera,"podras","will be able").
verbo(singular,primera,"podre","could").
verbo(singular,segunda,"podras","could").
verbo(singular,tercera,"podra","could").
verbo(plural,primera,"podriamos","could").
verbo(plural,tercera,"podrian","could").
%tener
verbo(singular,primera,"tengo","have").
verbo(singular,segunda,"tienes","have").
verbo(singular,tercera,"tiene","has").
verbo(plural,primera,"tenemos","have").
verbo(plural,tercera,"tienen","they have").
verbo(singular,primera,"tuve","had").
verbo(singular,segunda,"tuviste","saw").
verbo(singular,tercera,"tuvo","had").
verbo(plural,primera,"tuvimos","had").
verbo(plural,tercera,"tuvieron","they had").
verbo(singular,primera,"tendre","will have").
verbo(singular,segunda,"tendras","will have").
verbo(singular,tercera,"tendra","will have").
verbo(plural,primera,"tendremos","will have").
verbo(plural,tercera,"tendran","will have").
verbo(singular,primera,"tendria","would have").
verbo(singular,segunda,"tendrias","would have").
verbo(singular,tercera,"tendria","would have").
verbo(plural,primera,"tendriamos","would have").
verbo(plural,tercera,"tendrian","would have").
%hacer
verbo(singular,primera,"hago","make").
verbo(singular,segunda,"haces","do").
verbo(singular,tercera,"hace","does").
verbo(plural,primera,"hacemos","make").
verbo(plural,tercera,"hacen","make").
verbo(singular,primera,"hice","did").
verbo(singular,segunda,"hiciste","did").
verbo(singular,tercera,"hizo","did").
verbo(plural,primera,"hicimos","did").
verbo(plural,tercera,"hicieron","made").
verbo(singular,primera,"hare","will do").
verbo(singular,segunda,"haras","will do").
verbo(singular,tercera,"hara","will do").
verbo(plural,primera,"haremos","will").
verbo(plural,tercera,"haran","they will").
verbo(singular,primera,"haria","would do").
verbo(singular,segunda,"harias","would do").
verbo(singular,tercera,"haria","would do").
verbo(plural,primera,"hariamos","would do").
verbo(plural,tercera,"harian","would do").
%decir
verbo(singular,primera,"digo","say").
verbo(singular,segunda,"dices","dices").
verbo(singular,tercera,"dice","says").
verbo(plural,primera,"decimos","say").
verbo(plural,tercera,"dicen","they say").
verbo(singular,primera,"dije","said").
verbo(singular,segunda,"dijiste","said").
verbo(singular,tercera,"dijo","said").
verbo(plural,primera,"dijimos","said").
verbo(plural,tercera,"dijeron","they said").
verbo(singular,primera,"dire","will say").
verbo(singular,segunda,"diras","will say").
verbo(singular,tercera,"dira","will tell").
verbo(plural,primera,"diremos","will say").
verbo(plural,tercera,"diran","they will say").
verbo(singular,primera,"diria","would say").
verbo(singular,segunda,"dirias","would say").
verbo(singular,tercera,"diria","would say").
verbo(plural,primera,"diremos","would say").
verbo(plural,tercera,"diran","they would say").
%ver
verbo(singular,primera,"veo","see").
verbo(singular,segunda,"ves","see").
verbo(singular,tercera,"ve","go").
verbo(plural,primera,"vemos","see").
verbo(plural,tercera,"ven","come").
verbo(singular,primera,"vi","saw").
verbo(singular,segunda,"viste","dresses").
verbo(singular,tercera,"vio","saw").
verbo(plural,primera,"vimos","saw").
verbo(plural,tercera,"vieron","they saw").
verbo(singular,primera,"ver?","will see").
verbo(singular,segunda,"ver?","will see").
verbo(singular,tercera,"ver?","will see").
verbo(plural,primera,"veremos","will see").
verbo(plural,tercera,"ver?","they will see").
verbo(singular,primera,"ver?","would see").
verbo(singular,segunda,"ver?s","would see").
verbo(singular,tercera,"ver?","would see").
verbo(plural,primera,"ver?mos","would see").
verbo(plural,tercera,"ver?n","they would see").
%unir
verbo(singular,primera,"uno","join").
verbo(singular,tercera,"une","joins").
verbo(plural,primera,"unimos","join").
verbo(plural,tercera,"unen","join").
verbo(singular,segunda,"uniste","joined").
verbo(plural,primera,"unimos","joined").
verbo(plural,tercera,"unieron","they joined").
verbo(plural,primera,"uniremos","will join").
verbo(plural,tercera,"uniran","will join").
verbo(singular,primera,"unire","will join").
verbo(plural,tercera,"uniran","will join").
%dar
verbo(singular,primera,"doy","give").
verbo(singular,segunda,"das","give").
verbo(singular,tercera,"da","gives").
verbo(plural,tercera,"dan","give").
verbo(plural,tercera,"dieron","gave").
verbo(singular,primera,"di","gave").
verbo(plural,primera,"daremos","will give").
verbo(singular,tercera,"daria","would give").
verbo(singular,segunda,"darias","would give").
verbo(plural,tercera,"darian","would give").
%querer
verbo(singular,primera,"quiero","want").
verbo(singular,tercera,"quiere","wants").
verbo(singular,primera,"quise","wanted").
verbo(singular,tercera,"quiso","wanted").
verbo(plural,primera,"quisimos","wanted").
%creer
verbo(singular,primera,"creo","believe").
verbo(singular,tercera,"cree","believes").
verbo(plural,primera,"creemos","believe").
verbo(singular,primera,"creia","believed").
verbo(singular,tercera,"creyo","did believe").
verbo(singular,tercera,"creera","will believe").
verbo(singular,segunda,"creeras","will believe").
%pesar
verbo(singular,primera,"peso","weigh").
verbo(plural,primera,"pesamos","weigh").
verbo(plural,segunda,"pesan","weigh").
verbo(singular,segunda,"pesas","weigh").
verbo(singular,segunda,"pesaste","weighed").
verbo(singular,primera,"pesar?","weigh").
verbo(singular,segunda,"pesar?","weighed").
verbo(plural,primera,"pesaremos","will weigh").
verbo(plural,tercera,"pesara","will weigh").
verbo(singular,primera,"pesaria","would weigh").
verbo(singular,tercera,"pesaria","would weigh").
verbo(plural,primera,"pesariamos","would weigh").
%saber
verbo(singular,segunda,"sabe","know").
verbo(plural,primera,"sabemos","know").
verbo(singular,primera,"se","know").
verbo(singular,tercera,"sabe","knows").
verbo(singular,tercera,"supo","knew").
verbo(singular,segunda,"sabras","will know").
verbo(plural,primera,"sabremos","will know").
verbo(singular,segunda,"sabrias","would know").
verbo(singular,primera,"sabria","would know").
verbo(singular,segunda,"sabes","know").
verbo(plural,tercera,"saben","know").
verbo(singular,tercera,"supo","knew").
verbo(singular,segunda,"sabras","will know").
verbo(singular,tercera,"sabran","would know").
%deber
verbo(plural,primera,"debemos","must").
verbo(singular,primera,"debia","must").
verbo(singular,tercera,"debian","must have").
verbo(plural,primera,"debimos","must have").
verbo(plural,tercera,"debieron","had to").
verbo(singular,segunda,"deberias","should").
verbo(singular,tercera,"deberia","should").
verbo(plural,tercera,"deberian","should").
%seguir
verbo(plural,primera,"seguimos","follow").
verbo(plural,tercera,"siguieron","followed").
verbo(plural,tercera,"seguirian","would follow").
%Permanecer
verbo(singular,primera,"permanezco","remain").
verbo(plural,primera,"permanecemos","remain").
verbo(singular,segunda,"permanece","remain").
verbo(plural,segunda,"permanecen","remain").
verbo(singular,tercera,"permanece","remains").
verbo(plural,tercera,"permanecen","remain").
verbo(singular,primera,"permanecia","remained").
verbo(plural,primera,"permaneciamos","remained").
verbo(singular,segunda,"permanecia","remained").
verbo(plural,segunda,"permanecian","remained").
verbo(singular,tercera,"permanecia","remained").
verbo(plural,tercera,"permanecian","remained").
%Dormir
verbo(singular,primera,"duermo","sleep").
verbo(plural,primera,"dormimos","sleep").
verbo(singular,segunda,"duerme","sleep").
verbo(plural,segunda,"duermen","sleep").
verbo(singular,tercera,"duerme","sleeps").
verbo(plural,tercera,"duermen","sleep").
verbo(singular,primera,"durmio","slept").
verbo(plural,primera,"dormimos","slept").
verbo(singular,segunda,"durmio","slept").
verbo(plural,segunda,"durmieron","slept").
verbo(singular,tercera,"durmio","slept").
verbo(plural,tercera,"durmieron","slept").
%Jugar
verbo(singular,primera,"juego","play").
verbo(plural,primera,"jugamos","play").
verbo(singular,segunda,"juega","play").
verbo(plural,segunda,"juegan","play").
verbo(singular,tercera,"juega","plays").
verbo(plural,tercera,"juegan","play").
verbo(singular,primera,"jugue","played").
verbo(plural,primera,"jugamos","played").
verbo(singular,segunda,"jugo","played").
verbo(plural,segunda,"jugaron","played").
verbo(singular,tercera,"jugo","played").
verbo(plural,tercera,"jugaron","played").
%Trabajar
verbo(singular,primera,"trabajo","work").
verbo(plural,primera,"trabajamos","work").
verbo(singular,segunda,"trabaja","work").
verbo(plural,segunda,"trabajan","work").
verbo(singular,tercera,"trabaja","works").
verbo(plural,tercera,"trabajan","work").
verbo(singular,primera,"trabaje","worked").
verbo(plural,primera,"trabajamos","worked").
verbo(singular,segunda,"trabajo","worked").
verbo(plural,segunda,"trabajaron","worked").
verbo(singular,tercera,"trabajo","worked").
verbo(plural,tercera,"trabajaron","worked").
%Ir
verbo(singular,primera,"voy","go").
verbo(plural,primera,"vamos","go").
verbo(singular,segunda,"va","go").
verbo(plural,segunda,"van","go").
verbo(singular,tercera,"va","goes").
verbo(plural,tercera,"van","go").
verbo(singular,primera,"fui","went").
verbo(plural,primera,"fuimos","went").
verbo(singular,segunda,"fue","went").
verbo(plural,segunda,"fueron","went").
verbo(singular,tercera,"fue","went").
verbo(plural,tercera,"fueron","went").
%Comprar
verbo(singular,primera,"compro","buy").
verbo(plural,primera,"compramos","buy").
verbo(singular,segunda,"compra","buy").
verbo(plural,segunda,"compran","buy").
verbo(singular,tercera,"compra","buys").
verbo(plural,tercera,"compran","buy").
verbo(singular,primera,"compro","bought").
verbo(plural,primera,"compramos","bought").
verbo(singular,segunda,"compra","bought").
verbo(plural,segunda,"compraron","bought").
verbo(singular,tercera,"compra","bought").
verbo(plural,tercera,"compraron","bought").
%Entender
verbo(singular,primera,"entiendo","understand").
verbo(plural,primera,"entendemos","understand").
verbo(singular,segunda,"entiende","understand").
verbo(plural,segunda,"entienden","understand").
verbo(singular,tercera,"entiende","understands").
verbo(plural,tercera,"entienden","understand").
verbo(singular,primera,"entendi","understood").
verbo(plural,primera,"entendimos","understood").
verbo(singular,segunda,"entendio","understood").
verbo(plural,segunda,"entendieron","understood").
verbo(singular,tercera,"entendio","understood").
verbo(plural,tercera,"entendieron","understood").
%Usar
verbo(singular,primera,"uso","use").
verbo(plural,primera,"usamos","use").
verbo(singular,segunda,"usa","use").
verbo(plural,segunda,"usan","use").
verbo(singular,tercera,"usa","uses").
verbo(plural,tercera,"usan","use").
verbo(singular,primera,"use","used").
verbo(plural,primera,"usamos","used").
verbo(singular,segunda,"uso","used").
verbo(plural,segunda,"usaron","used").
verbo(singular,tercera,"uso","used").
verbo(plural,tercera,"usaron","used").
%Tomar
verbo(singular,primera,"tomo","drink").
verbo(plural,primera,"tomamos","drink").
verbo(singular,segunda,"toma","drink").
verbo(plural,segunda,"toman","drink").
verbo(singular,tercera,"toma","drinks").
verbo(plural,tercera,"toman","drink").
verbo(singular,primera,"tome","drank").
verbo(plural,primera,"tomamos","drank").
verbo(singular,segunda,"tomo","drank").
verbo(plural,segunda,"tomaron","drank").
verbo(singular,tercera,"tomo","drank").
verbo(plural,tercera,"tomaron","drank").
%Conducir
verbo(singular,primera,"conduzo","drive").
verbo(plural,primera,"conducimos","drive").
verbo(singular,segunda,"conduce","drive").
verbo(plural,segunda,"conducen","drive").
verbo(singular,tercera,"conduce","drives").
verbo(plural,tercera,"conducen","drive").
verbo(singular,primera,"conduje","drove").
verbo(plural,primera,"condujiste","drove").
verbo(singular,segunda,"condujo","drove").
verbo(plural,segunda,"condujeron","drove").
verbo(singular,tercera,"condujo","drove").
verbo(plural,tercera,"condujeron","drove").
%Escribir
verbo(singular,primera,"escribo","write").
verbo(plural,primera,"escribimos","write").
verbo(singular,segunda,"escribe","write").
verbo(plural,segunda,"escriben","write").
verbo(singular,tercera,"escribe","writes").
verbo(plural,tercera,"escriben","write").
verbo(singular,primera,"escribi","wrote").
verbo(plural,primera,"escribimos","wrote").
verbo(singular,segunda,"escribio","wrote").
verbo(plural,segunda,"escribieron","wrote").
verbo(singular,tercera,"escribio","wrote").
verbo(plural,tercera,"escribieron","wrote").
%Leer
verbo(singular,primera,"leo","read").
verbo(plural,primera,"leemos","read").
verbo(singular,segunda,"lee","read").
verbo(plural,segunda,"leen","read").
verbo(singular,tercera,"lee","reads").
verbo(plural,tercera,"leen","read").
verbo(singular,primera,"lei","read").
verbo(plural,primera,"leimos","read").
verbo(singular,segunda,"leyo","read").
verbo(plural,segunda,"leyeron","read").
verbo(singular,tercera,"leyo","read").
verbo(plural,tercera,"leyeron","read").
%Estudiar
verbo(singular,primera,"estudio","study").
verbo(plural,primera,"estudiamos","study").
verbo(singular,segunda,"estudia","study").
verbo(plural,segunda,"estudian","study").
verbo(singular,tercera,"estudia","studies").
verbo(plural,tercera,"estudian","study").
verbo(singular,primera,"estudie","studied").
verbo(plural,primera,"estudiamos","studied").
verbo(singular,segunda,"estudio","studied").
verbo(plural,segunda,"estudiaron","studied").
verbo(singular,tercera,"estudio","studied").
verbo(plural,tercera,"estudiaron","studied").
%Programar
verbo(singular,primera,"programo","program").
verbo(plural,primera,"programamos","program").
verbo(singular,segunda,"programa","program").
verbo(plural,segunda,"programan","program").
verbo(singular,tercera,"programa","programs").
verbo(plural,tercera,"programan","program").
verbo(singular,primera,"programe","programmed").
verbo(plural,primera,"programamos","programmed").
verbo(singular,segunda,"programo","programmed").
verbo(plural,segunda,"programaron","programmed").
verbo(singular,tercera,"programo","programmed").
verbo(plural,tercera,"programaron","programmed").
%Caminar
verbo(singular,primera,"camino","walk").
verbo(plural,primera,"caminamos","walk").
verbo(singular,segunda,"camina","walk").
verbo(plural,segunda,"caminan","walk").
verbo(singular,tercera,"camina","walks").
verbo(plural,tercera,"caminan","walk").
verbo(singular,primera,"camine","walked").
verbo(plural,primera,"caminamos","walked").
verbo(singular,segunda,"camino","walked").
verbo(plural,segunda,"caminaron","walked").
verbo(singular,tercera,"camino","walked").
verbo(plural,tercera,"caminaron","walked").
%Correr
verbo(singular,primera,"corro","run").
verbo(plural,primera,"corremos","run").
verbo(singular,segunda,"corre","run").
verbo(plural,segunda,"corren","run").
verbo(singular,tercera,"corre","runs").
verbo(plural,tercera,"corren","run").
verbo(singular,primera,"corri","ran").
verbo(plural,primera,"corrimos","ran").
verbo(singular,segunda,"corrio","ran").
verbo(plural,segunda,"corrieron","ran").
verbo(singular,tercera,"corrio","ran").
verbo(plural,tercera,"corrieron","ran").
%Guardar
verbo(singular,primera,"guardo","keep").
verbo(plural,primera,"guardamos","keep").
verbo(singular,segunda,"guarda","keep").
verbo(plural,segunda,"guardan","keep").
verbo(singular,tercera,"guarda","keeps").
verbo(plural,tercera,"guardan","keep").
verbo(singular,primera,"guarde","kept").
verbo(plural,primera,"guardamos","kept").
verbo(singular,segunda,"guardo","kept").
verbo(plural,segunda,"guardaron","kept").
verbo(singular,tercera,"guardo","kept").
verbo(plural,tercera,"guardaron","kept").
%Salvar
verbo(singular,primera,"salvo","save").
verbo(plural,primera,"salvamos","save").
verbo(singular,segunda,"salva","save").
verbo(plural,segunda,"salvan","save").
verbo(singular,tercera,"salva","saves").
verbo(plural,tercera,"salvan","save").
verbo(singular,primera,"salve","saved").
verbo(plural,primera,"salvamos","saved").
verbo(singular,segunda,"salvo","saved").
verbo(plural,segunda,"salvaron","saved").
verbo(singular,tercera,"salvo","saved").
verbo(plural,tercera,"salvaron","saved").
%Registrar
verbo(singular,primera,"registro","register").
verbo(plural,primera,"registramos","register").
verbo(singular,segunda,"registra","register").
verbo(plural,segunda,"registran","register").
verbo(singular,tercera,"registra","registers").
verbo(plural,tercera,"registran","register").
verbo(singular,primera,"registre","registered").
verbo(plural,primera,"registramos","registered").
verbo(singular,segunda,"registro","registered").
verbo(plural,segunda,"registraron","registered").
verbo(singular,tercera,"registro","registered").
verbo(plural,tercera,"registraron","registered").
%Pensar
verbo(singular,primera,"pienso","think").
verbo(plural,primera,"pensamos","think").
verbo(singular,segunda,"piensa","think").
verbo(plural,segunda,"piensan","think").
verbo(singular,tercera,"piensa","thinks").
verbo(plural,tercera,"piensan","think").
verbo(singular,primera,"pense","though").
verbo(plural,primera,"pensamos","though").
verbo(singular,segunda,"penso","though").
verbo(plural,segunda,"pensaron","though").
verbo(singular,tercera,"penso","though").
verbo(plural,tercera,"pensaron","though").
%Traducir
verbo(singular,primera,"traduzco","translate").
verbo(plural,primera,"traducimos","translate").
verbo(singular,segunda,"traduce","translate").
verbo(plural,segunda,"traducen","translate").
verbo(singular,tercera,"traduce","translates").
verbo(plural,tercera,"traducen","translate").
verbo(singular,primera,"traduje","translated").
verbo(plural,primera,"tradujimos","translated").
verbo(singular,segunda,"tradujo","translated").
verbo(plural,segunda,"tradujeron","translated").
verbo(singular,tercera,"tradujo","translated").
verbo(plural,tercera,"tradujeron","translated").
%Imprimir
verbo(singular,primera,"imprimo","print").
verbo(plural,primera,"imprimimos","print").
verbo(singular,segunda,"imprime","print").
verbo(plural,segunda,"imprimen","print").
verbo(singular,tercera,"imprime","prints").
verbo(plural,tercera,"imprimen","print").
verbo(singular,primera,"imprimi","printed").
verbo(plural,primera,"imprimimos","printed").
verbo(singular,segunda,"imprimio","printed").
verbo(plural,segunda,"imprimieron","printed").
verbo(singular,tercera,"imprimio","printed").
verbo(plural,tercera,"imprimieron","printed").
%Volar
verbo(singular,primera,"vuelo","fly").
verbo(plural,primera,"volamos","fly").
verbo(singular,segunda,"vuela","fly").
verbo(plural,segunda,"vuelan","fly").
verbo(singular,tercera,"vuela","flies").
verbo(plural,tercera,"vuelan","fly").
verbo(singular,primera,"vole","flew").
verbo(plural,primera,"volamos","flew").
verbo(singular,segunda,"volo","flew").
verbo(plural,segunda,"volaron","flew").
verbo(singular,tercera,"volo","flew").
verbo(plural,tercera,"volaron","flew").
%Hablar
verbo(singular,primera,"hablo","talk").
verbo(plural,primera,"hablamos","talk").
verbo(singular,segunda,"habla","talk").
verbo(plural,segunda,"hablan","talk").
verbo(singular,tercera,"habla","talks").
verbo(plural,tercera,"hablan","talk").
verbo(singular,primera,"hable","talked").
verbo(plural,primera,"hablamos","talked").
verbo(singular,segunda,"hablo","talked").
verbo(plural,segunda,"hablaron","talked").
verbo(singular,tercera,"hablo","talked").
verbo(plural,tercera,"hablaron","talked").
%Sentar
verbo(singular,primera,"siento","sit").
verbo(plural,primera,"sentamos","sit").
verbo(singular,segunda,"sienta","sit").
verbo(plural,segunda,"sientan","sit").
verbo(singular,tercera,"sienta","sits").
verbo(plural,tercera,"sientan","sit").
verbo(singular,primera,"sente","sat").
verbo(plural,primera,"sentamos","sat").
verbo(singular,segunda,"sento","sat").
verbo(plural,segunda,"sentaron","sat").
verbo(singular,tercera,"sento","sat").
verbo(plural,tercera,"sentaron","sat").
%Amar
verbo(singular,primera,"amo","love").
verbo(plural,primera,"amamos","love").
verbo(singular,segunda,"ama","love").
verbo(plural,segunda,"aman","love").
verbo(singular,tercera,"ama","loves").
verbo(plural,tercera,"aman","love").
verbo(singular,primera,"ame","loved").
verbo(plural,primera,"amamos","loved").
verbo(singular,segunda,"amo","loved").
verbo(plural,segunda,"amaron","loved").
verbo(singular,tercera,"amo","loved").
verbo(plural,tercera,"amaron","loved").

verbo(_, _, [], []).

%%%%%%%%%%%%%%Adjetivos(Adjetivos)%%%%%%%%%%%%%%%%

adjetivo(femenino, plural, "rojas", "red").
adjetivo(femenino, singular, "roja", "red").
adjetivo(masculino, singular, "rojo", "red").
adjetivo(masculino, plural, "rojos", "red").

adjetivo(femenino, plural, "pequenas", "little").
adjetivo(femenino, singular, "pequena", "little").
adjetivo(masculino, singular, "pequeno", "little").
adjetivo(masculino, plural, "pequenos", "little").

adjetivo(femenino, plural, "malas", "bad").
adjetivo(femenino, singular, "mala", "bad").
adjetivo(masculino, singular, "malo", "bad").
adjetivo(masculino, plural, "malos", "bad").

adjetivo(femenino,singular,"buena","good").
adjetivo(femenino,plural,"buenas","good").
adjetivo(masculino,singular,"bueno","good").
adjetivo(masculino,plural,"buenos","good").
adjetivo(masculino,singular,"caro","expensive").
adjetivo(masculino,plural,"caros","expensive").
adjetivo(femenino,singular,"cara","expensive").
adjetivo(femenino,plural,"caras","expensive").
adjetivo(_,singular,"popular","popular").
adjetivo(_,plural,"populares","popular").
adjetivo(_,singular,"computacional","computational").
adjetivo(_,plural,"computacionales","computational").
adjetivo(_,singular,"artificial","artificial").
adjetivo(_,plural,"artificiales","artificial").
adjetivo(masculino,singular,"experto","expert").
adjetivo(masculino,plural,"expertos","expert").
adjetivo(femenino,singular,"experta","expert").
adjetivo(femenino,plural,"expertas","expert").
adjetivo(_,singular,"natural","natural").
adjetivo(_,plural,"naturales","natural").
adjetivo(masculino,singular,"bonito","pretty").
adjetivo(femenino,singular,"bonita","pretty").
adjetivo(masculino,singular,"viejo","old").
adjetivo(femenino,singular,"vieja","old").

adjetivo(_,singular,"su","his").
adjetivo(_,plural,"sus","their").
adjetivo(_,singular,"mi","my").
adjetivo(_,singular,"uno","one").
adjetivo(_,singular,"mismo","same").
adjetivo(_,singular,"ese","that").
adjetivo(_,singular,"otro","other").
adjetivo(_,plural,"otros","others").
adjetivo(_,singular,"esa","that").
adjetivo(_,plural,"tres","three").
adjetivo(_,plural,"otras","others").
adjetivo(_,singular,"tal","such").
adjetivo(_,singular,"cierto","certain").
adjetivo(_,singular,"mal","bad").
adjetivo(_,singular,"algun","some").

adjetivo(_, _, [], []).

%%%%%%%%%%%%%%%Interjecciones(Interjections)%%%%%%%%%%%%%%

interjeccion("hola", "hello").
interjeccion("hola", "hi").

interjeccion([], []).

%%%%%%%%%%%%%%%%Preposiciones(AdPositions)%%%%%%%%%%%%%%%

preposicion("a", "to").
preposicion("de", "from").
preposicion("de", "of").
preposicion("por", "by").
preposicion("que", "to").
preposicion("con", "with").
preposicion("quien","who").
preposicion("que","what").
preposicion("donde","where").
preposicion("cuando","when").
preposicion("y","and").
preposicion("o","or").

preposicion("de","from").
preposicion("en","in").
preposicion("por","by").
preposicion("con","with").
preposicion("para","for").
preposicion("sin","without").
preposicion("sobre","on").
preposicion("entre","between").
preposicion("hasta","until").
preposicion("desde","since").
preposicion("durante","during").
preposicion("segun","according").
preposicion("contra","against").
preposicion("sino","or else").
preposicion("ante","before").
preposicion("hacia","toward").
preposicion("tras","after").

preposicion([], []).

%%%%%%%%%%%%%%%%%%Especiales%%%%%%%%%%%%%%%%%%%

preg("quien","who").
preg("que","what").
preg("donde","where").
preg("cuando","when").
preg("como","how").

preg([],[]).

pronom_per(primera, singular, "yo").

pronom_per(primera, plural, "nosotros").
pronom_per(primera, plural, "nos").
pronom_per(primera, plural, "nosotras").

pronom_per(segunda, singular, "usted").
pronom_per(segunda, singular, "tu").
pronom_per(segunda, singular, "ti").
pronom_per(segunda, singular, "te").

pronom_per(segunda, plural, "vosotros").
pronom_per(segunda, plural, "vosotras").
pronom_per(segunda, plural, "vos").
pronom_per(segunda, plural, "os").

pronom_per(tercera, singular, "ella").
pronom_per(tercera, singular, "ello").
pronom_per(tercera, singular, "la").
pronom_per(tercera, singular, "el").

pronom_per(tercera, plural, "ellos").
pronom_per(tercera, plural, "ellas").
pronom_per(tercera, plural, "les").

auxq(singular,primera,"do").
auxq(singular,segunda,"do").
auxq(singular,tercera,"does").
auxq(plural,primera,"do").
auxq(plural,segunda,"do").
auxq(plural,tercera,"do").
